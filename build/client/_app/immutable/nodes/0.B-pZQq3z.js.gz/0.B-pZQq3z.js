import{L as l}from"../chunks/_layout.BCQcnv1e.js";const e=!1,o=Object.freeze(Object.defineProperty({__proto__:null,ssr:e},Symbol.toStringTag,{value:"Module"}));export{l as component,o as universal};
