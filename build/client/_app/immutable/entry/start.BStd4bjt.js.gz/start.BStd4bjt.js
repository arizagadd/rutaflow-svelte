import{a as t}from"../chunks/entry.CHxi3ese.js";export{t as start};
