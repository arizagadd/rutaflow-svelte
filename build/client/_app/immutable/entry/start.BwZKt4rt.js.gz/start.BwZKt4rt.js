import{a as t}from"../chunks/entry.CGLtPgHd.js";export{t as start};
