import{a as t}from"../chunks/entry.D1_SSu4j.js";export{t as start};
