import{a as t}from"../chunks/entry.Dp10X52-.js";export{t as start};
