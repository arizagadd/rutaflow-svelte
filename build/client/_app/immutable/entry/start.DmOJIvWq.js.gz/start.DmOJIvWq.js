import{a as t}from"../chunks/entry.DDZpC47V.js";export{t as start};
