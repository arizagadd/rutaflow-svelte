import{a as t}from"../chunks/entry.BlliC2ps.js";export{t as start};
