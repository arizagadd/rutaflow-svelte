import{a as t}from"../chunks/entry.DhsYo6LP.js";export{t as start};
