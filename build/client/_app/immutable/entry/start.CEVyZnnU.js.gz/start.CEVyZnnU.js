import{a as t}from"../chunks/entry.BJuz583F.js";export{t as start};
