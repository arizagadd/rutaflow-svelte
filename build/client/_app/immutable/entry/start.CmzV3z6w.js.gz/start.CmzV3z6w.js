import{a as t}from"../chunks/entry.QeUDNh-0.js";export{t as start};
