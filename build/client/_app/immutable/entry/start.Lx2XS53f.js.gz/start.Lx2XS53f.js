import{a as t}from"../chunks/entry.B6U0hnRL.js";export{t as start};
