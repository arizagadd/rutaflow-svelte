import{a as t}from"../chunks/entry.CUF_41Lp.js";export{t as start};
