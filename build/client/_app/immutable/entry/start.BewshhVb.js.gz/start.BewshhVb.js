import{a as t}from"../chunks/entry.C-XgvcNx.js";export{t as start};
