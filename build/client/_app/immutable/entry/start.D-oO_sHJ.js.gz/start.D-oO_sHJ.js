import{a as t}from"../chunks/entry.-kw5acw-.js";export{t as start};
