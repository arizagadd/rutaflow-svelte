import{a as t}from"../chunks/entry.BLFBpQrZ.js";export{t as start};
