import{a as t}from"../chunks/entry.DbeSo8um.js";export{t as start};
