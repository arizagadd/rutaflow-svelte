import{a as t}from"../chunks/entry.nnZsqDy6.js";export{t as start};
