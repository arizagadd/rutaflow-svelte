import{a as t}from"../chunks/entry.YrHLBCAJ.js";export{t as start};
