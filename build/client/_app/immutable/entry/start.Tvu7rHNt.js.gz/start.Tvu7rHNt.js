import{a as t}from"../chunks/entry.L2aZ2szG.js";export{t as start};
