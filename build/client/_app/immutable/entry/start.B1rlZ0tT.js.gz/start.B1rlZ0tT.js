import{a as t}from"../chunks/entry.CEzUa9Lo.js";export{t as start};
