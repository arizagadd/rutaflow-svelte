import{a as t}from"../chunks/entry.C4fYmPTv.js";export{t as start};
