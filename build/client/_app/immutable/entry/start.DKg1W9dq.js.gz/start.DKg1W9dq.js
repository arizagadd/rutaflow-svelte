import{a as t}from"../chunks/entry.Dd6Gio1i.js";export{t as start};
