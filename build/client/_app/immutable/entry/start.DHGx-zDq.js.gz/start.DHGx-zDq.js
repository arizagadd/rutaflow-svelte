import{a as t}from"../chunks/entry.C_RfsJo8.js";export{t as start};
