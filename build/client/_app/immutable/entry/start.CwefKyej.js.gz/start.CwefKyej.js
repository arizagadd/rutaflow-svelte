import{a as t}from"../chunks/entry.C6b6MIv-.js";export{t as start};
