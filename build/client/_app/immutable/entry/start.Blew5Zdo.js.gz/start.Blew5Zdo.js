import{a as t}from"../chunks/entry.81mA7piW.js";export{t as start};
