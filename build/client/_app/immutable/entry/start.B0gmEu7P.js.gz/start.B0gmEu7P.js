import{a as t}from"../chunks/entry.DEyHJ2Rm.js";export{t as start};
