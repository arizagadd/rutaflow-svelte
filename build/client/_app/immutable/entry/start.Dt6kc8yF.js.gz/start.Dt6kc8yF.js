import{a as t}from"../chunks/entry.DsyFFyAa.js";export{t as start};
