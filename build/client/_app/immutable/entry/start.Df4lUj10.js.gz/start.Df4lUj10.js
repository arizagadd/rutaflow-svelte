import{a as t}from"../chunks/entry.DY_tWZkh.js";export{t as start};
