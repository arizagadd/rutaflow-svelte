import{a as t}from"../chunks/entry.MCo-nQIh.js";export{t as start};
