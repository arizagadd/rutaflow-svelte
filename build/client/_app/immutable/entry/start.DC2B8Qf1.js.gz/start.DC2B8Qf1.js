import{a as t}from"../chunks/entry.fxb4ED8n.js";export{t as start};
