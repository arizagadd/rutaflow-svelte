import{a as t}from"../chunks/entry.trRdy9B7.js";export{t as start};
