import{a as t}from"../chunks/entry.DlWua9u_.js";export{t as start};
