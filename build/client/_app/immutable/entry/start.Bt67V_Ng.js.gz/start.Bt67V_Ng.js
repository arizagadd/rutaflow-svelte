import{a as t}from"../chunks/entry.BF_ftpd4.js";export{t as start};
