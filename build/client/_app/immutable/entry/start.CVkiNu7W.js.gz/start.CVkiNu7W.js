import{a as t}from"../chunks/entry.lFdho03Q.js";export{t as start};
