import{a as t}from"../chunks/entry.BxUesXR0.js";export{t as start};
