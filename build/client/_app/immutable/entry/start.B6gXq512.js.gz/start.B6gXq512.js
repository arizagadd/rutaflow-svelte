import{a as t}from"../chunks/entry.D-1wuOmU.js";export{t as start};
