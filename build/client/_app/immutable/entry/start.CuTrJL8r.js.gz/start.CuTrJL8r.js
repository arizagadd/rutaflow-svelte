import{a as t}from"../chunks/entry.CFIwT7d9.js";export{t as start};
