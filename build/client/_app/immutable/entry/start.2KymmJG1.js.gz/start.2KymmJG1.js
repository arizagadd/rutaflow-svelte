import{a as t}from"../chunks/entry.HFVLD9c0.js";export{t as start};
