import{a as t}from"../chunks/entry.BLDF1BkO.js";export{t as start};
