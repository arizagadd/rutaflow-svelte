import{a as t}from"../chunks/entry.EYHo1N48.js";export{t as start};
