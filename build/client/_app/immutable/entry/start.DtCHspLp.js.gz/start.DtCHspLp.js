import{a as t}from"../chunks/entry.C6uPgoyH.js";export{t as start};
