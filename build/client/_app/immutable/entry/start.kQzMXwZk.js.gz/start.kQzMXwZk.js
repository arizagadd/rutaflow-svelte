import{a as t}from"../chunks/entry.DHhq2ZG4.js";export{t as start};
