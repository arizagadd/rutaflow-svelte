import{a as t}from"../chunks/entry.GZbPsMv8.js";export{t as start};
