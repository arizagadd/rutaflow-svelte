import{a as t}from"../chunks/entry.BwhmJIPv.js";export{t as start};
