import{a as t}from"../chunks/entry.QNuWOBC9.js";export{t as start};
