import{a as t}from"../chunks/entry.jZYOJi-C.js";export{t as start};
