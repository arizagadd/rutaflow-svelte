import{a as t}from"../chunks/entry.HrauOrnK.js";export{t as start};
