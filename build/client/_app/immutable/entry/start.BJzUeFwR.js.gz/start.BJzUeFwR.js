import{a as t}from"../chunks/entry.CY99jdJL.js";export{t as start};
