import{a as t}from"../chunks/entry.BVaGJF9L.js";export{t as start};
