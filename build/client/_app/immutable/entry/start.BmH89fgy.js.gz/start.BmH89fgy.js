import{a as t}from"../chunks/entry.bI2BqXYX.js";export{t as start};
