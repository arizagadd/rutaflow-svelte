import{a as t}from"../chunks/entry.CMwx3tcL.js";export{t as start};
