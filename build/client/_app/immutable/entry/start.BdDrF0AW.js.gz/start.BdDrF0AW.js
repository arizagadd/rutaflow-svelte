import{a as t}from"../chunks/entry.O-PURUYZ.js";export{t as start};
