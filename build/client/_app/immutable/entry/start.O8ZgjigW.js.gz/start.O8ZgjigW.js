import{a as t}from"../chunks/entry.Bk-5knQp.js";export{t as start};
