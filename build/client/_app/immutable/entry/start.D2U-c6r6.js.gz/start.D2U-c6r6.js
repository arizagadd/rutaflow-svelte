import{a as t}from"../chunks/entry.BtqwzgYx.js";export{t as start};
