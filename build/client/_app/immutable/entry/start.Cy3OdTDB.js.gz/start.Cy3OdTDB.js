import{a as t}from"../chunks/entry.6CDJCSkr.js";export{t as start};
