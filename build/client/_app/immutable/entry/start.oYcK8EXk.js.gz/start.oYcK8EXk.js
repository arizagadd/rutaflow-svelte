import{a as t}from"../chunks/entry.BmW3zoA4.js";export{t as start};
