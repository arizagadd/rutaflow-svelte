import{a as t}from"../chunks/entry.hK-GcuAY.js";export{t as start};
