import{a as t}from"../chunks/entry.Cz4PnlvI.js";export{t as start};
