import{a as t}from"../chunks/entry.ajYgCYmH.js";export{t as start};
