import{a as t}from"../chunks/entry.Cx3P4KtL.js";export{t as start};
