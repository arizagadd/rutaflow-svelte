import{a as t}from"../chunks/entry.9C0Ntne4.js";export{t as start};
