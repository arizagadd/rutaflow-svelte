import{a as t}from"../chunks/entry.v_rLx4bx.js";export{t as start};
