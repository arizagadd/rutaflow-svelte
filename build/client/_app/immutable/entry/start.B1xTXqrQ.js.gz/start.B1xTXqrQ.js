import{a as t}from"../chunks/entry.DTfJnh1-.js";export{t as start};
