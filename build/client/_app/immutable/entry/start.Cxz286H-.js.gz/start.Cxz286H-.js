import{a as t}from"../chunks/entry.C7b4g-D9.js";export{t as start};
