import{a as t}from"../chunks/entry.Cjnemdwm.js";export{t as start};
