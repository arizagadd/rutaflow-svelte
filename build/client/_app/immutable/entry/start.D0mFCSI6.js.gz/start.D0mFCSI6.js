import{a as t}from"../chunks/entry.DzTzH-_9.js";export{t as start};
