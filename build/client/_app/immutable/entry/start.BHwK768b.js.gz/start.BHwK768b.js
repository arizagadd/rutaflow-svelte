import{a as t}from"../chunks/entry.DD9R0qop.js";export{t as start};
