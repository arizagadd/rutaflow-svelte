import{a as t}from"../chunks/entry.BwQ2z8Tu.js";export{t as start};
