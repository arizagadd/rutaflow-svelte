import{a as t}from"../chunks/entry.BvAh3ZLl.js";export{t as start};
