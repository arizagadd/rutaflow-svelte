import{a as t}from"../chunks/entry.cQM2eaz1.js";export{t as start};
