import{a as t}from"../chunks/entry.DAbes_4C.js";export{t as start};
