import{a as t}from"../chunks/entry.P3y4B2kX.js";export{t as start};
