import{a as t}from"../chunks/entry.C0BZ6FMh.js";export{t as start};
