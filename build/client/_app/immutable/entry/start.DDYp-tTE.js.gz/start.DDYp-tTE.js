import{a as t}from"../chunks/entry.KrXTcCyY.js";export{t as start};
