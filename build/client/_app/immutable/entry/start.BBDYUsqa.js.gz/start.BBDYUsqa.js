import{a as t}from"../chunks/entry.BxVh0qv0.js";export{t as start};
