import{a as t}from"../chunks/entry.CDO_KCFi.js";export{t as start};
