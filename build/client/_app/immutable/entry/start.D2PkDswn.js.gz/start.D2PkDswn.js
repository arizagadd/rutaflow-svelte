import{a as t}from"../chunks/entry.zY2rL7Aj.js";export{t as start};
