import{a as t}from"../chunks/entry.FhSNKcGe.js";export{t as start};
