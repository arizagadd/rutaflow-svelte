import{a as t}from"../chunks/entry.whp6KrXT.js";export{t as start};
