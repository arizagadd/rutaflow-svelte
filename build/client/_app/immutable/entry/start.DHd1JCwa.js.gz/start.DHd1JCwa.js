import{a as t}from"../chunks/entry.CqLYEtX4.js";export{t as start};
