import{a as t}from"../chunks/entry.D6I6KACp.js";export{t as start};
