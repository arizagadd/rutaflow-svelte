import{a as t}from"../chunks/entry.DRKOeUpc.js";export{t as start};
