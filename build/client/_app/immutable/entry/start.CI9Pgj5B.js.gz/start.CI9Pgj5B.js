import{a as t}from"../chunks/entry.BV59Jjrm.js";export{t as start};
