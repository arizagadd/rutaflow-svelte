import{a as t}from"../chunks/entry.DOB0qcZQ.js";export{t as start};
