import{a as t}from"../chunks/entry.Ku51L176.js";export{t as start};
