import{a as t}from"../chunks/entry.sf7mHP6E.js";export{t as start};
