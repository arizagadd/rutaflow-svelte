import{a as t}from"../chunks/entry.CqP54awF.js";export{t as start};
