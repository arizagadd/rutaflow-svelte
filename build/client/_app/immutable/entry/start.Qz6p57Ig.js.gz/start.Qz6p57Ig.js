import{a as t}from"../chunks/entry.CXu_Rfag.js";export{t as start};
