import{a as t}from"../chunks/entry.DxB0GszC.js";export{t as start};
