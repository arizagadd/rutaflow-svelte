import{a as t}from"../chunks/entry.CDff0lR3.js";export{t as start};
