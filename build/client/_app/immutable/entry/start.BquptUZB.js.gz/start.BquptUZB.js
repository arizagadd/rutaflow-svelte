import{a as t}from"../chunks/entry.B3_bMcWf.js";export{t as start};
