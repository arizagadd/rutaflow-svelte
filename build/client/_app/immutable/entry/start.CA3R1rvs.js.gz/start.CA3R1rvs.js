import{a as t}from"../chunks/entry.BL0zc3kS.js";export{t as start};
