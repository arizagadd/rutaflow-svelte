import{a as t}from"../chunks/entry.uawVg834.js";export{t as start};
