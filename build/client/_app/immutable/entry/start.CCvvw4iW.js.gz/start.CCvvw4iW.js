import{a as t}from"../chunks/entry.DD_5a_We.js";export{t as start};
