import{a as t}from"../chunks/entry.C1eIWhz-.js";export{t as start};
