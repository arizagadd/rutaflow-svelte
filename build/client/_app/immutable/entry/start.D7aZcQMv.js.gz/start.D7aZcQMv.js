import{a as t}from"../chunks/entry.90E2-GdU.js";export{t as start};
