import{a as t}from"../chunks/entry.DmWBXmmU.js";export{t as start};
