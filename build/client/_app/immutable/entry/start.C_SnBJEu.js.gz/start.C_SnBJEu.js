import{a as t}from"../chunks/entry.uKRy6c2X.js";export{t as start};
