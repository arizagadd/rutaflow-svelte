import{a as t}from"../chunks/entry.BE5aq_cL.js";export{t as start};
