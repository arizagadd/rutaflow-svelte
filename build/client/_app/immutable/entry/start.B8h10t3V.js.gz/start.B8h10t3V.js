import{a as t}from"../chunks/entry.BTVRHbxG.js";export{t as start};
