import{a as t}from"../chunks/entry.B-LPgbXi.js";export{t as start};
