import{a as t}from"../chunks/entry.DU-rtAnE.js";export{t as start};
